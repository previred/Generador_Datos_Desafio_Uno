# Generador Datos Desafio

1.- Para este proyecto debe estar ejecutandose el servicio REST.

2.- El proyecto se debe cargar como un Proyecto java en Eclipse

3.- Debe ser pasado por parametro la direccion o PATH del archivo de salida.

Ej.

java Test C:\\directory\\archivo.json

4.- Ejecutar como Java Application la clase que contiene el Main: DesafioMain.java y como argumento el directorio donde se crea el archivo json de salida. Ej: C:\\directory\\archivo.json

